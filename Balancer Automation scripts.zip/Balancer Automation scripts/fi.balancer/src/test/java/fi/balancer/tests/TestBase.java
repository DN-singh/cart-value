package fi.balancer.tests;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import fi.balancer.base.BasePage;
import fi.balancer.utils.ExtentReportManager;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase{
    protected WebDriver driver;
    protected Properties config;
    protected String baseUrl;

    @BeforeSuite
    public void setupSuite() {
        ExtentReportManager.initReports();
    }

    @BeforeClass
    public void setup() {
        try {
            config = new Properties();
            FileInputStream configFile = new FileInputStream(System.getProperty("user.dir") + File.separator+ "/src/main/resources/configuration/config.properties");
            config.load(configFile);
            
            baseUrl = config.getProperty("url", "https://balancer.fi/");
            
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            
            // Add any browser options if needed
            if (Boolean.parseBoolean(config.getProperty("headless", "false"))) {
                options.addArguments("--headless");
            }
            
            driver = new ChromeDriver(options);
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
            
            driver.get(baseUrl);
            
            configFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @AfterMethod
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            BasePage.screenShot(driver, result.getName() + "_failure");
        }
        
        // Update test status in reports
        ExtentReportManager.getTest().assignCategory(result.getTestClass().getName());
        
        if (result.getStatus() == ITestResult.FAILURE) {
            ExtentReportManager.testFail(result.getThrowable().getMessage());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            ExtentReportManager.testPass("Test passed successfully");
        } else {
            ExtentReportManager.testSkip("Test skipped");
        }
    }

    @AfterMethod
	@AfterClass
    public void tearDown() {
        ExtentReportManager.flushReports();
        if (driver != null) {
           // driver.quit();
        }
    }
    
    public WebDriver getDriver() {
        return this.driver;
    }
}
