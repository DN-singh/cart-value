package fi.balancer.tests;


import org.testng.annotations.Test;

import fi.balancer.pages.HomePage;
import fi.balancer.pages.PoolsPage;
import fi.balancer.utils.ExtentReportManager;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;

import java.util.List;

@Listeners(fi.balancer.utils.TestListener.class)

public class PoolsPageTest extends TestBase {
    private HomePage homePage;
    private PoolsPage poolsPage;

    @BeforeMethod
    public void setupTest() {
        ExtentReportManager.createTest(getClass().getSimpleName());
        homePage = new HomePage(driver);
    }
    
    @BeforeClass
    public void initPages() {
       
        poolsPage = new PoolsPage(getDriver());
    }

    @Test (priority =1)
    public void verifyPageTitle() {
        ExtentReportManager.logInfo("Verifying page title");
        String pageTitle = driver.getTitle();
        Assert.assertTrue(pageTitle.contains("Balancer"), "Page title does not contain 'Balancer'");
        ExtentReportManager.logInfo("Page title verified: " + pageTitle);
    }

 

    @Test (priority =2) 
    public void verifyFilterFunctionality() throws InterruptedException {

    	ExtentReportManager.logInfo("Clicking on Pools link");
        poolsPage = homePage.clickOnPoolsLink();
        
        ExtentReportManager.logInfo("Clicking on filter button");
        poolsPage.clickFilterButton();
       
        ExtentReportManager.logInfo("Selecting Weighted filter option");
        poolsPage.selectWeightedFilter();
        
        ExtentReportManager.logInfo("Closing filter dialog");
        poolsPage.closeFilter();
        
        ExtentReportManager.logPass("Filter functionality tested successfully");
    }

    @Test(priority =3)
    public void verifyTableHeaders() {
        ExtentReportManager.logInfo("Getting table headers");
        List<String> headers = poolsPage.extractAndPrintTableHeaders();  
        
        ExtentReportManager.logInfo("Table headers found: " + headers);
        Assert.assertTrue(headers.size() > 0, "No table headers found");
        
        boolean hasPoolHeader = headers.stream().anyMatch(header -> header.contains("Pool"));
        Assert.assertTrue(hasPoolHeader, "Table does not contain Pool column");
        
        ExtentReportManager.logPass("Table headers verified successfully");
    }

    @Test(priority =4 ,dependsOnMethods ="verifyTableHeaders")
    public void verifyFirstPoolData() {
        ExtentReportManager.logInfo("Getting first pool data");
        List<WebElement> poolData = poolsPage.extractAndPrintFirstPoolData();  
        
        Assert.assertFalse(poolData.isEmpty(), "Pool data is empty");
      
        ExtentReportManager.logPass("First pool data verified successfully");
    }
    
    
}