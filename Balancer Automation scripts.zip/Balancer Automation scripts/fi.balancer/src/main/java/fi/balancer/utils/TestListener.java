package fi.balancer.utils;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import fi.balancer.base.BasePage;


public class TestListener implements ITestListener {
	
	


	//WebDriver driver;
    
    @Override
    public void onTestStart(ITestResult result) {
        System.out.println("Starting test: " + result.getName());
        ExtentReportManager.initReports();
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("Test passed: " + result.getName());
        ExtentReportManager.testPass("Test passed successfully.");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        System.out.println("Test failed: " + result.getName());
        
        // Get driver instance to take screenshot
        Object testClass = result.getInstance();
        WebDriver driver = null;
        if (testClass instanceof BasePage) {
            driver = ((BasePage) testClass).driver;
        }
     
        if (driver != null) {
        // Capture screenshot
        String screenshotPath = BasePage.screenShot(driver, result.getName() + "_failure");
        
        // Attach screenshot to report
        ExtentReportManager.attachScreenshot(screenshotPath);
        } else {
           System.err.println("WebDriver instance is null2. Screenshot not captured.");
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        System.out.println("Test skipped: " + result.getName());
        ExtentReportManager.testSkip("Test skipped.");
    }

    @Override
    public void onStart(ITestContext context) {
        System.out.println("Test suite started: " + context.getName());
    }

    @Override
    public void onFinish(ITestContext context) {
        System.out.println("Test suite finished: " + context.getName());
        ExtentReportManager.flushReports();
    }
}