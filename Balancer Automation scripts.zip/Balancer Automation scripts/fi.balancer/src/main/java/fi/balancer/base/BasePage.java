package fi.balancer.base;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;

public class BasePage {
    public WebDriver driver;
    protected  WebDriverWait wait;
    public static JavascriptExecutor js;
    private static final String SCREENSHOT_DIR = System.getProperty("user.dir") 
    	    + File.separator + "screenshots";

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    protected WebElement waitForElementToBeClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    protected  WebElement waitForElementToBeVisible(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    protected List<WebElement> waitForElementsToBeVisible(List<WebElement> elements) {
        return wait.until(ExpectedConditions.visibilityOfAllElements(elements));
    }

    protected WebElement waitForElementToBePresent(By locator) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    protected void click(WebElement element) {
        waitForElementToBeClickable(element).click();
    }

    public  void jsClick(WebElement element) {
        js.executeScript("arguments[0].click();", waitForElementToBeVisible(element));
    }

    protected String getText(WebElement element) {
        return waitForElementToBeVisible(element).getText();
    }

    protected String getHexColor(WebElement element, String cssProperty) {
        String rgbaColor = waitForElementToBeVisible(element).getCssValue(cssProperty);
        return Color.fromString(rgbaColor).asHex();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    protected void captureScreenshot(String testName) {
        screenShot(driver, testName);
    }

    public static void scrollToTop() {
    	    js.executeScript("window.scrollTo(0, 0);");
    	}
    
    
    public static String screenShot(WebDriver driver, String filename) {
    	
    	if (driver == null) {
              throw new IllegalArgumentException("WebDriver instance is null1. Cannot take screenshot.");
          }
    	  
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		 
        String destinationPath = SCREENSHOT_DIR + File.separator + filename + "_" + dateName + ".png";
        File destination = new File(destinationPath);
        try {
            FileUtils.copyFile(source, destination);
            System.out.println("Screenshot saved at: " + destination.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
	


		return destinationPath;
	}
}