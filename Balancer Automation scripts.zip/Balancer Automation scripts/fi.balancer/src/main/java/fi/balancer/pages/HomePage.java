package fi.balancer.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import fi.balancer.base.BasePage;

public class HomePage extends BasePage {

    @FindBy(xpath = "//a[normalize-space()='Pools']")
    private WebElement poolsLink;

    @FindBy(xpath = "//div[@class='css-1wlp89b']//h1")
    private WebElement mainHeader;

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public String getMainHeaderText() {
        return getText(mainHeader);
    }

    public PoolsPage clickOnPoolsLink() {
        click(poolsLink);
        return new PoolsPage(driver);
    }

    public String getPoolsLinkColorBeforeClick() {
        return getHexColor(poolsLink, "color");
    }
}