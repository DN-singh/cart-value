package fi.balancer.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class ExtentReportManager {
    private static ExtentReports extent;
    private static Map<Integer, ExtentTest> extentTestMap = new HashMap<>();
    
    public static synchronized ExtentReports initReports() {
        if (extent == null) {
            // Create reports directory if it doesn't exist
            File directory = new File("target/reports/");
            if (!directory.exists()) {
                directory.mkdirs();
            }
            
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter("target/reports/BalancerTestReport.html");
            sparkReporter.config().setDocumentTitle("Balancer Automation Report");
            sparkReporter.config().setReportName("Balancer Test Results");
            sparkReporter.config().setTheme(Theme.DARK);
            
            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);
            extent.setSystemInfo("OS", System.getProperty("os.name"));
            extent.setSystemInfo("Java Version", System.getProperty("java.version"));
            extent.setSystemInfo("Application", "Balancer Finance");
            extent.setSystemInfo("Environment", "QA");
            extent.setSystemInfo("Tester", "Durga Singh");
        }
        return extent;
    }
    
    public static synchronized ExtentTest createTest(String testName) {
        ExtentTest test = extent.createTest(testName);
        extentTestMap.put((int) Thread.currentThread().getId(), test);
        return test;
    }
    
    public static synchronized ExtentTest getTest() {
        return extentTestMap.get((int) Thread.currentThread().getId());
    }
    
    public static synchronized void logInfo(String message) {
        getTest().log(Status.INFO, message);
    }
    
    public static synchronized void logPass(String message) {
        getTest().log(Status.PASS, message);
    }
    
    public static synchronized void logFail(String message) {
        getTest().log(Status.FAIL, message);
    }
    
    public static synchronized void testPass(String message) {
        getTest().pass(message);
    }
    
    public static synchronized void testFail(String message) {
        getTest().fail(message);
    }
    
    public static synchronized void testSkip(String message) {
        getTest().skip(message);
    }
    
    public static synchronized void attachScreenshot(String screenshotPath) {
        getTest().addScreenCaptureFromPath(screenshotPath);
    }
    
    public static synchronized void flushReports() {
        extent.flush();
    }
}