package fi.balancer.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import fi.balancer.base.BasePage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PoolsPage extends BasePage {

    @FindBy(xpath = "//a[normalize-space()='Pools']")
    private WebElement poolsLink;

    @FindBy(xpath = "//button[@class='chakra-button css-1b4zdee']")
    private WebElement filterButton;

    @FindBy(xpath = "//button[@aria-label='Close']")
    private WebElement closeFilterButton;

    @FindBy(xpath = "(//p[@class='chakra-text css-84y1uf'][normalize-space()='Weighted'])[1]")
    private WebElement weightedFilterOption;
    
    @FindBy(xpath = "(//p[@class='chakra-text css-84y1uf'][normalize-space()='Stable'])[1]")
    private WebElement stableFilterOption;

    @FindBy(xpath = "//div[@class='css-1elyb0']//p[contains(@class, 'chakra-text')]")
    private List<WebElement> tableHeaders;

    @FindBy(css = "div.css-1ki54i")
    private WebElement firstPoolRow;

    // First pool details
    @FindBy(css = "div.css-1ki54i ul.chakra-wrap__list span.chakra-badge")
    private List<WebElement> poolTokens;

    @FindBy(css = "div.css-1ki54i div.css-16igsqs")
    private WebElement poolDetails;

    @FindBy(css = "div.css-1ki54i p[title*='$']")
    private List<WebElement> poolFinancialInfo;

    @FindBy(css = "div.css-1ki54i p.chakra-text.css-14c1bqn")
    private WebElement poolApr;
    
    @FindBy(xpath ="//button[normalize-space()='Reset all']")
    private WebElement resetAll;

    public PoolsPage(WebDriver driver) {
        super(driver);
    	
    }

    public String getPoolsLinkColorAfterClick() {
        return getHexColor(poolsLink, "color");
    }

    public void clickFilterButton() {
       jsClick(filterButton);
    }

    public void selectWeightedFilter() {
        jsClick(weightedFilterOption);
    }
    
    public void selectStableFilter() {
        jsClick(stableFilterOption);
    }

    public void closeFilter() {
    	jsClick(closeFilterButton);
    }

   public void resetFilter() {
	   jsClick(resetAll);
   }
    
    
    public List<String> extractAndPrintTableHeaders() {
        List<WebElement> headers = driver.findElements(By.xpath("//div[@class='css-1elyb0']//p[contains(@class, 'chakra-text')]"));
        
        List<String> headerTexts = headers.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());

        System.out.println("Column Headers: " + headerTexts);
        return headerTexts;
    }
    
    
    public List<WebElement> extractAndPrintFirstPoolData() {
    	
    	WebElement firstRow = driver.findElement(By.cssSelector("div.css-1ki54i"));
    	List<WebElement> tokens = firstRow.findElements(By.cssSelector("ul.chakra-wrap__list span.chakra-badge"));
        System.out.println("\nPool Composition:");
        
        for (WebElement token : tokens) {
            System.out.println(token.getText());  // value under pool name e.g. wstETH 20%
        }
        // it will fetch value under Details tab
        String details = firstRow.findElement(By.cssSelector("div.css-16igsqs")).getText();
        System.out.println("\nDetails: " + details);

        // it will fetch value under TVL tab
        String tvl = firstRow.findElement(By.cssSelector("p[title*='$']")).getText();
        System.out.println("\nTVL: " + tvl);

        // it will fetch value under volume tab
        String volume = firstRow.findElements(By.cssSelector("p[title*='$']")).get(1).getText();
        System.out.println("\nVolume (24h): " + volume);

        // it will fetch value under APR tab
        String apr = firstRow.findElement(By.cssSelector("p.chakra-text.css-14c1bqn")).getText();
        System.out.println("\nAPR: " + apr);
        
    	return tokens;
    }
    

}

