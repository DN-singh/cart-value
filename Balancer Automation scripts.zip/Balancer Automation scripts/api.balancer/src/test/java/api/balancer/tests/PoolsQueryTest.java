package api.balancer.tests;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import api.balancer.config.ConfigManager;
import api.balancer.pojo.GqlPoolFilter;
import api.balancer.pojo.Pool;
import api.balancer.pojo.PoolQueryRequest;
import api.balancer.pojo.PoolResponse;
import api.balancer.utils.APIEndpoints;
import api.balancer.utils.ExtentReportManager;
import api.balancer.utils.GraphQLUtils;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import org.testng.Assert;
import org.testng.annotations.*;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PoolsQueryTest {
    
    @BeforeSuite
    public void setUp() {
        RestAssured.baseURI = APIEndpoints.getGraphQLEndpoint();
    }
    
    @BeforeMethod
    public void setUpTest(Object[] params) {
        ExtentReportManager.startTest("Get Pools Test", "Verify stable pools on Mainnet");
    }
    
    @Test
    public void testGetStablePools() {
        ExtentTest test = ExtentReportManager.getTest();
        
        try {
            // Build the request
            test.log(Status.INFO, "Building GraphQL request");
            
            // Load query from file
            String queryString = GraphQLUtils.loadGraphQLQuery("GetPools.graphql");
            
            // Build variables object
            PoolQueryRequest variables = PoolQueryRequest.builder()
                    .first(ConfigManager.getInstance().getPoolsLimit())
                    .skip(ConfigManager.getInstance().getPoolsSkip())
                    .orderBy("totalLiquidity")
                    .orderDirection("desc")
                    .where(GqlPoolFilter.builder()
                            //.chainIn("MAINNET")
                            .poolTypeIn(Arrays.asList("STABLE"))
                            .build())
                    .build();
            
            // Create request body
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("query", queryString);
            requestBody.put("variables", variables);
            
            test.log(Status.INFO, "Sending GraphQL request to " + APIEndpoints.getGraphQLEndpoint());
            
            // Send request
            Response response = RestAssured.given()
                    .contentType(ContentType.JSON)
                    .body(requestBody)
                    .when().log().all()
                    .post();
            
            response.then().log().all();
            
            // Log response
            test.log(Status.INFO, "Received response with status code: " + response.getStatusCode());
            
            // Validate status code
            Assert.assertEquals(response.getStatusCode(), 200, "Response status code should be 200");
            test.log(Status.PASS, "Status code validation passed: 200");
            
            // Parse response
            PoolResponse poolResponse = response.as(PoolResponse.class);
            
            // Validate response is not null
            Assert.assertNotNull(poolResponse.getData(), "Response data should not be null");
            test.log(Status.PASS, "Response data validation passed: not null");
            
            // Validate pools list is not empty
            List<Pool> pools = poolResponse.getData().getPoolGetPools();
            Assert.assertFalse(pools.isEmpty(), "Pools list should not be empty");
            test.log(Status.PASS, "Pools list validation passed: not empty");
            
            // Log the number of pools returned
            test.log(Status.INFO, "Number of pools returned: " + pools.size());
            
            // Validate pools content
            validatePools(pools, test);
            
        } catch (Exception e) {
            test.log(Status.FAIL, "Test failed with exception: " + e.getMessage());
            Assert.fail("Test failed with exception: " + e.getMessage(), e);
        }
    }
    
    private void validatePools(List<Pool> pools, ExtentTest test) {
        // Validate pool count matches the request limit
        int expectedCount = Math.min(ConfigManager.getInstance().getPoolsLimit(), pools.size());
        Assert.assertEquals(pools.size(), expectedCount, "Number of pools should match the requested limit");
        test.log(Status.PASS, "Pool count validation passed: " + pools.size());
        
        // Validate each pool has required fields
        for (int i = 0; i < pools.size(); i++) {
            Pool pool = pools.get(i);
            
            // Validate basic pool properties
            Assert.assertNotNull(pool.getId(), "Pool ID should not be null");
            Assert.assertNotNull(pool.getName(), "Pool name should not be null");
            Assert.assertNotNull(pool.getAddress(), "Pool address should not be null");
           // Assert.assertEquals(pool.getChain(), "MAINNET", "Pool chain should be MAINNET");
            Assert.assertEquals(pool.getType(), "STABLE", "Pool type should be STABLE");
            
            // Validate dynamic data
            Assert.assertNotNull(pool.getDynamicData(), "Pool dynamic data should not be null");
            Assert.assertNotNull(pool.getDynamicData().getTotalLiquidity(), "Total liquidity should not be null");
            Assert.assertNotNull(pool.getDynamicData().getVolume24h(), "Volume 24h should not be null");
            Assert.assertNotNull(pool.getDynamicData().getFees24h(), "Fees 24h should not be null");
            Assert.assertNotNull(pool.getDynamicData().getTotalShares(), "Total shares should not be null");
            Assert.assertNotNull(pool.getDynamicData().getSwapFee(), "SwapFee should not be null");
            
            test.log(Status.PASS, "Pool #" + (i + 1) + " validation passed: " + pool.getName());
        }
        
        // Validate pools are sorted by totalLiquidity in descending order
        for (int i = 0; i < pools.size() - 1; i++) {
            double current = Double.parseDouble(pools.get(i).getDynamicData().getTotalLiquidity());
            double next = Double.parseDouble(pools.get(i + 1).getDynamicData().getTotalLiquidity());
            Assert.assertTrue(current >= next, "Pools should be sorted by totalLiquidity in descending order");
        }
        test.log(Status.PASS, "Pools sorting validation passed: descending by totalLiquidity");
    }
    
   
    
    @AfterSuite
    public void tearDown() {
        ExtentReportManager.getExtentReports().flush();
    }
}