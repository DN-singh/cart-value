package api.balancer.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DynamicData {
    private String totalLiquidity;
    private String volume24h;
    private String fees24h;
    private String totalShares;
    private String swapFee;
}