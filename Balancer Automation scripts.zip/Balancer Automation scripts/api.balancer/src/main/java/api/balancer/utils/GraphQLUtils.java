package api.balancer.utils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.apache.commons.io.IOUtils;

public class GraphQLUtils {
    
    public static String loadGraphQLQuery(String queryFileName) {
        try (InputStream inputStream = GraphQLUtils.class.getClassLoader().getResourceAsStream("graphql/" + queryFileName)) {
            if (inputStream == null) {
                throw new RuntimeException("Cannot find GraphQL query file: " + queryFileName);
            }
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException("Error loading GraphQL query: " + queryFileName, e);
        }
    }
}