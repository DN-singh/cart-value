package api.balancer.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PoolResponse {
    private Data data;
    
    @lombok.Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Data {
        private List<Pool> poolGetPools;
    }
}