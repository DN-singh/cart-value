package api.balancer.utils;

import api.balancer.config.ConfigManager;

public class APIEndpoints {
    private static final String BASE_URL = ConfigManager.getInstance().getBaseUrl();
    
    public static String getGraphQLEndpoint() {
        return BASE_URL;
    }
}