package api.balancer.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pool {
    private String id;
    private String name;
    private String address;
    private String chain;
    private String type;
    private String protocolVersion;
    private DynamicData dynamicData;
}