package api.balancer.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigManager {
    private static final Properties properties = new Properties();
    private static ConfigManager instance;
    
    private ConfigManager() {
        loadProperties();
    }
    
    public static synchronized ConfigManager getInstance() {
        if (instance == null) {
            instance = new ConfigManager();
        }
        return instance;
    }
    
    private void loadProperties() {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            if (inputStream != null) {
                properties.load(inputStream);
            } else {
                throw new RuntimeException("Unable to find config.properties");
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config properties", e);
        }
    }
    
    public String getProperty(String key) {
        return properties.getProperty(key);
    }
    
    public String getBaseUrl() {
        return getProperty("api.baseUrl");
    }
    
    public int getPoolsLimit() {
        return Integer.parseInt(getProperty("request.pools.limit"));
    }
    
    public int getPoolsSkip() {
        return Integer.parseInt(getProperty("request.pools.skip"));
    }
    
    public String getReportPath() {
        return getProperty("report.path");
    }
}