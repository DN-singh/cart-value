package api.balancer.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PoolQueryRequest {
    private int first;
    private int skip;
    private String orderBy;
    private String orderDirection;
    private GqlPoolFilter where;
}