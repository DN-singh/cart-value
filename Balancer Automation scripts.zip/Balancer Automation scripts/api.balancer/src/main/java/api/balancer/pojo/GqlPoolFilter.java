package api.balancer.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GqlPoolFilter {
   // private String chainIn;
    private List<String> poolTypeIn;
}
